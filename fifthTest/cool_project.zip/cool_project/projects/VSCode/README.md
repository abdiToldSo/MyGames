## VSCode Project

It uses the provided Makefile in src/Makefile to build project.

VSCode workspace (tasks.json, launch.json...) are configured for source files in ../../src directory.